using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Category
{
    [Key]
    public int CategoryID { get; set; }

    public int EventID { get; set; }

    [ForeignKey(nameof(EventID))]
    public Event? Event { get; set; }

    [Required, MaxLength(100)]
    public string CategoryName { get; set; } = string.Empty;

    [Range(0.01, 1000)]
    public decimal DistanceKm { get; set; }

    [Range(0, 100000)]
    public decimal EntryFee { get; set; } = 0.00m;

    // Navigation properties
    public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
}
