using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Event
{
    [Key]
    public int EventID { get; set; }

    public int OrganiserID { get; set; }

    [ForeignKey(nameof(OrganiserID))]
    public User? Organiser { get; set; }

    [Required, MaxLength(200)]
    public string EventName { get; set; } = string.Empty;

    public DateTime EventDate { get; set; }

    [Required, MaxLength(300)]
    public string Location { get; set; } = string.Empty;

    [MaxLength(2000)]
    public string? Description { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Navigation properties
    public ICollection<Category> Categories { get; set; } = new List<Category>();
}
