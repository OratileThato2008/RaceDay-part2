using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Result
{
    [Key]
    public int ResultID { get; set; }

    public int EnrolmentID { get; set; }

    [ForeignKey(nameof(EnrolmentID))]
    public Enrolment? Enrolment { get; set; }

    public TimeSpan FinishTime { get; set; }

    public int? OverallPosition { get; set; }
}
