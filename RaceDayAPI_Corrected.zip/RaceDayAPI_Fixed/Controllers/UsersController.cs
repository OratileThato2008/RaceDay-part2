using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/users")]
[ApiController]
public class UsersController : ControllerBase
{
    private readonly RaceDayContext _context;

    public UsersController(RaceDayContext context)
    {
        _context = context;
    }

    // POST: api/users/register
    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterDto dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        // Only allow the two valid roles
        if (dto.UserRole != "Organiser" && dto.UserRole != "Participant")
            return BadRequest(new { message = "UserRole must be either 'Organiser' or 'Participant'." });

        if (await _context.Users.AnyAsync(u => u.Email == dto.Email))
            return BadRequest(new { message = "Email is already registered." });

        string hashedPassword = BCrypt.Net.BCrypt.HashPassword(dto.Password);

        var user = new User
        {
            FirstName = dto.FirstName,
            LastName = dto.LastName,
            Email = dto.Email,
            PasswordHash = hashedPassword,
            UserRole = dto.UserRole
        };

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        return Ok(new
        {
            message = "User registered successfully!",
            userId = user.UserID
        });
    }

    // POST: api/users/login
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginDto dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == dto.Email);

        if (user == null || !BCrypt.Net.BCrypt.Verify(dto.Password, user.PasswordHash))
            return Unauthorized(new { message = "Invalid email or password." });

        HttpContext.Session.SetInt32("UserID", user.UserID);
        HttpContext.Session.SetString("UserRole", user.UserRole);

        return Ok(new
        {
            message = "Login successful!",
            userId = user.UserID,
            role = user.UserRole
        });
    }

    // POST: api/users/logout
    [HttpPost("logout")]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return Ok(new { message = "Logged out successfully." });
    }

    // GET: api/users/{id}
    [HttpGet("{id}")]
    public async Task<IActionResult> GetProfile(int id)
    {
        var currentUserId = HttpContext.Session.GetInt32("UserID");
        var currentUserRole = HttpContext.Session.GetString("UserRole");

        if (currentUserId == null)
            return Unauthorized(new { message = "Please log in first." });

        // Owner or any Organiser may view
        if (currentUserId != id && currentUserRole != "Organiser")
            return Forbid();

        var user = await _context.Users.FindAsync(id);
        if (user == null)
            return NotFound(new { message = "User not found." });

        // Never return PasswordHash
        return Ok(new UserResponseDto
        {
            UserID = user.UserID,
            FirstName = user.FirstName,
            LastName = user.LastName,
            Email = user.Email,
            UserRole = user.UserRole
        });
    }
}
