using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/events")]
[ApiController]
public class EventsController : ControllerBase
{
    private readonly RaceDayContext _context;

    public EventsController(RaceDayContext context)
    {
        _context = context;
    }

    // GET: api/events (Public)
    [HttpGet]
    public async Task<IActionResult> GetAllEvents()
    {
        var events = await _context.Events
            .Include(e => e.Organiser)
            .Select(e => new EventResponseDto
            {
                EventID = e.EventID,
                EventName = e.EventName,
                EventDate = e.EventDate,
                Location = e.Location,
                Description = e.Description,
                CreatedAt = e.CreatedAt,
                OrganiserID = e.OrganiserID,
                OrganiserName = e.Organiser != null
                    ? e.Organiser.FirstName + " " + e.Organiser.LastName
                    : null
            })
            .ToListAsync();

        return Ok(events);
    }

    // GET: api/events/{id} (Public)
    [HttpGet("{id}")]
    public async Task<IActionResult> GetEventById(int id)
    {
        var ev = await _context.Events
            .Include(e => e.Organiser)
            .Where(e => e.EventID == id)
            .Select(e => new EventResponseDto
            {
                EventID = e.EventID,
                EventName = e.EventName,
                EventDate = e.EventDate,
                Location = e.Location,
                Description = e.Description,
                CreatedAt = e.CreatedAt,
                OrganiserID = e.OrganiserID,
                OrganiserName = e.Organiser != null
                    ? e.Organiser.FirstName + " " + e.Organiser.LastName
                    : null
            })
            .FirstOrDefaultAsync();

        if (ev == null)
            return NotFound(new { message = "Event not found." });

        return Ok(ev);
    }

    // POST: api/events (Organiser only)
    [HttpPost]
    public async Task<IActionResult> CreateEvent([FromBody] EventDto dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var userId = HttpContext.Session.GetInt32("UserID");
        var userRole = HttpContext.Session.GetString("UserRole");

        if (userId == null)
            return Unauthorized(new { message = "Please log in first." });

        if (userRole != "Organiser")
            return Forbid();

        var newEvent = new Event
        {
            OrganiserID = userId.Value,
            EventName = dto.EventName,
            EventDate = dto.EventDate,
            Location = dto.Location,
            Description = dto.Description,
            CreatedAt = DateTime.UtcNow
        };

        _context.Events.Add(newEvent);
        await _context.SaveChangesAsync();

        return Ok(new { message = "Event created successfully!", eventId = newEvent.EventID });
    }

    // PUT: api/events/{id} (Owner Organiser only)
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateEvent(int id, [FromBody] EventDto dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var userId = HttpContext.Session.GetInt32("UserID");
        var userRole = HttpContext.Session.GetString("UserRole");

        if (userId == null)
            return Unauthorized(new { message = "Please log in first." });

        var ev = await _context.Events.FindAsync(id);
        if (ev == null)
            return NotFound(new { message = "Event not found." });

        // Must be Organiser AND the owner of this event
        if (userRole != "Organiser" || ev.OrganiserID != userId)
            return Forbid();

        ev.EventName = dto.EventName;
        ev.EventDate = dto.EventDate;
        ev.Location = dto.Location;
        ev.Description = dto.Description;

        await _context.SaveChangesAsync();
        return Ok(new { message = "Event updated successfully!" });
    }

    // DELETE: api/events/{id} (Owner Organiser only)
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        var userId = HttpContext.Session.GetInt32("UserID");
        var userRole = HttpContext.Session.GetString("UserRole");

        if (userId == null)
            return Unauthorized(new { message = "Please log in first." });

        var ev = await _context.Events.FindAsync(id);
        if (ev == null)
            return NotFound(new { message = "Event not found." });

        // Must be Organiser AND the owner of this event
        if (userRole != "Organiser" || ev.OrganiserID != userId)
            return Forbid();

        _context.Events.Remove(ev);
        await _context.SaveChangesAsync();

        return Ok(new { message = "Event deleted successfully!" });
    }
}
