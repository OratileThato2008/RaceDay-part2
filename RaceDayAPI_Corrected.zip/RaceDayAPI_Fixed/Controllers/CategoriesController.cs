using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api")]
[ApiController]
public class CategoriesController : ControllerBase
{
    private readonly RaceDayContext _context;

    public CategoriesController(RaceDayContext context)
    {
        _context = context;
    }

    // GET: api/events/{eventId}/categories (Public)
    [HttpGet("events/{eventId}/categories")]
    public async Task<IActionResult> GetCategoriesForEvent(int eventId)
    {
        var exists = await _context.Events.AnyAsync(e => e.EventID == eventId);
        if (!exists)
            return NotFound(new { message = "Event not found." });

        var categories = await _context.Categories
            .Where(c => c.EventID == eventId)
            .Select(c => new CategoryResponseDto
            {
                CategoryID = c.CategoryID,
                EventID = c.EventID,
                CategoryName = c.CategoryName,
                DistanceKm = c.DistanceKm,
                EntryFee = c.EntryFee
            })
            .ToListAsync();

        return Ok(categories);
    }

    // GET: api/categories/{id} (Public)
    [HttpGet("categories/{id}")]
    public async Task<IActionResult> GetCategoryById(int id)
    {
        var category = await _context.Categories
            .Where(c => c.CategoryID == id)
            .Select(c => new CategoryResponseDto
            {
                CategoryID = c.CategoryID,
                EventID = c.EventID,
                CategoryName = c.CategoryName,
                DistanceKm = c.DistanceKm,
                EntryFee = c.EntryFee
            })
            .FirstOrDefaultAsync();

        if (category == null)
            return NotFound(new { message = "Category not found." });

        return Ok(category);
    }

    // POST: api/events/{eventId}/categories (Owner Organiser only)
    [HttpPost("events/{eventId}/categories")]
    public async Task<IActionResult> AddCategory(int eventId, [FromBody] CategoryDto dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var userId = HttpContext.Session.GetInt32("UserID");
        var userRole = HttpContext.Session.GetString("UserRole");

        if (userId == null)
            return Unauthorized(new { message = "Please log in first." });

        if (userRole != "Organiser")
            return Forbid();

        var ev = await _context.Events.FindAsync(eventId);
        if (ev == null)
            return NotFound(new { message = "Event not found." });

        // Only the owner of the event may add categories
        if (ev.OrganiserID != userId)
            return Forbid();

        var category = new Category
        {
            EventID = eventId,
            CategoryName = dto.CategoryName,
            DistanceKm = dto.DistanceKm,
            EntryFee = dto.EntryFee
        };

        _context.Categories.Add(category);
        await _context.SaveChangesAsync();

        return Ok(new { message = "Category added successfully!", categoryId = category.CategoryID });
    }

    // PUT: api/categories/{id} (Owner Organiser only)
    [HttpPut("categories/{id}")]
    public async Task<IActionResult> UpdateCategory(int id, [FromBody] CategoryDto dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var userId = HttpContext.Session.GetInt32("UserID");
        var userRole = HttpContext.Session.GetString("UserRole");

        if (userId == null)
            return Unauthorized(new { message = "Please log in first." });

        if (userRole != "Organiser")
            return Forbid();

        var category = await _context.Categories
            .Include(c => c.Event)
            .FirstOrDefaultAsync(c => c.CategoryID == id);

        if (category == null)
            return NotFound(new { message = "Category not found." });

        // Only the owner of the parent event may update
        if (category.Event == null || category.Event.OrganiserID != userId)
            return Forbid();

        category.CategoryName = dto.CategoryName;
        category.DistanceKm = dto.DistanceKm;
        category.EntryFee = dto.EntryFee;

        await _context.SaveChangesAsync();
        return Ok(new { message = "Category updated successfully!" });
    }

    // DELETE: api/categories/{id} (Owner Organiser only)
    [HttpDelete("categories/{id}")]
    public async Task<IActionResult> DeleteCategory(int id)
    {
        var userId = HttpContext.Session.GetInt32("UserID");
        var userRole = HttpContext.Session.GetString("UserRole");

        if (userId == null)
            return Unauthorized(new { message = "Please log in first." });

        if (userRole != "Organiser")
            return Forbid();

        var category = await _context.Categories
            .Include(c => c.Event)
            .FirstOrDefaultAsync(c => c.CategoryID == id);

        if (category == null)
            return NotFound(new { message = "Category not found." });

        // Only the owner of the parent event may delete
        if (category.Event == null || category.Event.OrganiserID != userId)
            return Forbid();

        _context.Categories.Remove(category);
        await _context.SaveChangesAsync();
        return Ok(new { message = "Category deleted successfully!" });
    }
}
