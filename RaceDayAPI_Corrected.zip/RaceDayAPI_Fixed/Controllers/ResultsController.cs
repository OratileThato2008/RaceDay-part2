using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api")]
[ApiController]
public class ResultsController : ControllerBase
{
    private readonly RaceDayContext _context;

    public ResultsController(RaceDayContext context)
    {
        _context = context;
    }

    // POST: api/results (Organiser who owns the event only)
    [HttpPost("results")]
    public async Task<IActionResult> RecordResult([FromBody] ResultDto dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var userId = HttpContext.Session.GetInt32("UserID");
        var userRole = HttpContext.Session.GetString("UserRole");

        if (userId == null)
            return Unauthorized(new { message = "Please log in first." });

        if (userRole != "Organiser")
            return Forbid();

        // Verify enrolment exists and load related event for ownership check
        var enrolment = await _context.Enrolments
            .Include(e => e.Category)
                .ThenInclude(c => c!.Event)
            .FirstOrDefaultAsync(e => e.EnrolmentID == dto.EnrolmentID);

        if (enrolment == null)
            return NotFound(new { message = "Enrolment not found." });

        // Only the organiser who owns the event may record results
        if (enrolment.Category?.Event == null || enrolment.Category.Event.OrganiserID != userId)
            return Forbid();

        // One result per enrolment
        var existing = await _context.Results.FirstOrDefaultAsync(r => r.EnrolmentID == dto.EnrolmentID);
        if (existing != null)
            return BadRequest(new { message = "A result for this enrolment already exists." });

        var result = new Result
        {
            EnrolmentID = dto.EnrolmentID,
            FinishTime = dto.FinishTime,
            OverallPosition = dto.OverallPosition
        };

        _context.Results.Add(result);
        await _context.SaveChangesAsync();

        return Ok(new { message = "Result recorded successfully!", resultId = result.ResultID });
    }

    // GET: api/categories/{categoryId}/results (Public – leaderboard)
    [HttpGet("categories/{categoryId}/results")]
    public async Task<IActionResult> GetCategoryLeaderboard(int categoryId)
    {
        var exists = await _context.Categories.AnyAsync(c => c.CategoryID == categoryId);
        if (!exists)
            return NotFound(new { message = "Category not found." });

        var results = await _context.Results
            .Include(r => r.Enrolment)
                .ThenInclude(e => e!.Participant)
            .Where(r => r.Enrolment != null && r.Enrolment.CategoryID == categoryId)
            .OrderBy(r => r.OverallPosition)
            .Select(r => new ResultResponseDto
            {
                ResultID = r.ResultID,
                EnrolmentID = r.EnrolmentID,
                FinishTime = r.FinishTime,
                OverallPosition = r.OverallPosition,
                ParticipantID = r.Enrolment != null ? r.Enrolment.ParticipantID : null,
                ParticipantName = r.Enrolment != null && r.Enrolment.Participant != null
                    ? r.Enrolment.Participant.FirstName + " " + r.Enrolment.Participant.LastName
                    : null
            })
            .ToListAsync();

        return Ok(results);
    }

    // PUT: api/results/{id} (Owner Organiser only)
    [HttpPut("results/{id}")]
    public async Task<IActionResult> UpdateResult(int id, [FromBody] ResultDto dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var userId = HttpContext.Session.GetInt32("UserID");
        var userRole = HttpContext.Session.GetString("UserRole");

        if (userId == null)
            return Unauthorized(new { message = "Please log in first." });

        if (userRole != "Organiser")
            return Forbid();

        var result = await _context.Results
            .Include(r => r.Enrolment)
                .ThenInclude(e => e!.Category)
                    .ThenInclude(c => c!.Event)
            .FirstOrDefaultAsync(r => r.ResultID == id);

        if (result == null)
            return NotFound(new { message = "Result not found." });

        // Ownership check
        if (result.Enrolment?.Category?.Event == null ||
            result.Enrolment.Category.Event.OrganiserID != userId)
            return Forbid();

        result.FinishTime = dto.FinishTime;
        result.OverallPosition = dto.OverallPosition;

        await _context.SaveChangesAsync();
        return Ok(new { message = "Result updated successfully!" });
    }

    // DELETE: api/results/{id} (Owner Organiser only)
    [HttpDelete("results/{id}")]
    public async Task<IActionResult> DeleteResult(int id)
    {
        var userId = HttpContext.Session.GetInt32("UserID");
        var userRole = HttpContext.Session.GetString("UserRole");

        if (userId == null)
            return Unauthorized(new { message = "Please log in first." });

        if (userRole != "Organiser")
            return Forbid();

        var result = await _context.Results
            .Include(r => r.Enrolment)
                .ThenInclude(e => e!.Category)
                    .ThenInclude(c => c!.Event)
            .FirstOrDefaultAsync(r => r.ResultID == id);

        if (result == null)
            return NotFound(new { message = "Result not found." });

        // Ownership check
        if (result.Enrolment?.Category?.Event == null ||
            result.Enrolment.Category.Event.OrganiserID != userId)
            return Forbid();

        _context.Results.Remove(result);
        await _context.SaveChangesAsync();

        return Ok(new { message = "Result deleted successfully!" });
    }
}
