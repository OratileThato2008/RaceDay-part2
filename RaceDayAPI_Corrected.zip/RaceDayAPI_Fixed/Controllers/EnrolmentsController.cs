using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api")]
[ApiController]
public class EnrolmentsController : ControllerBase
{
    private readonly RaceDayContext _context;

    public EnrolmentsController(RaceDayContext context)
    {
        _context = context;
    }

    // POST: api/enrolments (Participant only)
    [HttpPost("enrolments")]
    public async Task<IActionResult> Enrol([FromBody] EnrolmentDto dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var userId = HttpContext.Session.GetInt32("UserID");
        var userRole = HttpContext.Session.GetString("UserRole");

        if (userId == null)
            return Unauthorized(new { message = "Please log in first." });

        if (userRole != "Participant")
            return BadRequest(new { message = "Only participants can enrol in events." });

        // Verify category exists
        var categoryExists = await _context.Categories.AnyAsync(c => c.CategoryID == dto.CategoryID);
        if (!categoryExists)
            return NotFound(new { message = "Category not found." });

        // Check if already enrolled
        var existing = await _context.Enrolments
            .FirstOrDefaultAsync(e => e.ParticipantID == userId.Value && e.CategoryID == dto.CategoryID);

        if (existing != null)
            return BadRequest(new { message = "You are already enrolled in this category." });

        var enrolment = new Enrolment
        {
            ParticipantID = userId.Value,
            CategoryID = dto.CategoryID,
            EnrolmentDate = DateTime.UtcNow
        };

        _context.Enrolments.Add(enrolment);
        await _context.SaveChangesAsync();

        return Ok(new { message = "Enrolment successful!", enrolmentId = enrolment.EnrolmentID });
    }

    // GET: api/users/{userId}/enrolments (Owner or Organiser)
    [HttpGet("users/{userId}/enrolments")]
    public async Task<IActionResult> GetUserEnrolments(int userId)
    {
        var currentUserId = HttpContext.Session.GetInt32("UserID");
        var currentUserRole = HttpContext.Session.GetString("UserRole");

        if (currentUserId == null)
            return Unauthorized(new { message = "Please log in first." });

        // Owner or any Organiser may view
        if (currentUserId != userId && currentUserRole != "Organiser")
            return Forbid();

        var enrolments = await _context.Enrolments
            .Include(e => e.Category)
                .ThenInclude(c => c!.Event)
            .Include(e => e.Participant)
            .Where(e => e.ParticipantID == userId)
            .Select(e => new EnrolmentResponseDto
            {
                EnrolmentID = e.EnrolmentID,
                ParticipantID = e.ParticipantID,
                ParticipantName = e.Participant != null
                    ? e.Participant.FirstName + " " + e.Participant.LastName
                    : null,
                CategoryID = e.CategoryID,
                CategoryName = e.Category != null ? e.Category.CategoryName : null,
                EventID = e.Category != null ? e.Category.EventID : null,
                EventName = e.Category != null && e.Category.Event != null
                    ? e.Category.Event.EventName
                    : null,
                EnrolmentDate = e.EnrolmentDate
            })
            .ToListAsync();

        return Ok(enrolments);
    }
}
