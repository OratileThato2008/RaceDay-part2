# RaceDayAPI – Corrected Version

## What was fixed

### Critical
- **PasswordHash never returned** – all endpoints now use response DTOs
- **Authorization bugs** – Update/Delete of Events, Categories and Results now require the *owner* Organiser (not just any Organiser)
- **Uniqueness** – Email is unique; one Result per Enrolment; one Enrolment per Participant+Category
- **Existence checks** – Category must exist before enroling; Enrolment must exist before recording a result
- **Role validation** – only `"Organiser"` or `"Participant"` accepted on register

### Other improvements
- `PublishAot` disabled (it breaks Swagger + EF Core during development)
- `launchUrl` set to `swagger`
- Leftover template `Todo` code removed from `Program.cs`
- Circular-reference handling added to JSON serialiser
- All DTOs moved into the `DTOs` folder with validation attributes
- Navigation properties and proper cascade/restrict rules in `OnModelCreating`
- `TrustServerCertificate=True` added to connection string (common LocalDB requirement)
- Consistent use of `DateTime.UtcNow`

---

## How to run

1. Make sure **SQL Server LocalDB** is installed.
2. Open a terminal in this folder and run:

```bash
dotnet restore
dotnet ef migrations add InitialCreate
dotnet ef database update
dotnet run
```

3. Open the browser at: **http://localhost:5022/swagger**

> If you do not have the EF tools installed:
> ```bash
> dotnet tool install --global dotnet-ef
> ```

---

## API Overview

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | /api/users/register | Public | Register |
| POST | /api/users/login | Public | Login (sets session) |
| POST | /api/users/logout | Session | Logout |
| GET | /api/users/{id} | Owner / Organiser | Profile |
| GET | /api/events | Public | List events |
| GET | /api/events/{id} | Public | Event details |
| POST | /api/events | Organiser | Create event |
| PUT/DELETE | /api/events/{id} | **Owner** Organiser | Update / delete |
| GET | /api/events/{id}/categories | Public | Categories for event |
| POST | /api/events/{id}/categories | **Owner** Organiser | Add category |
| PUT/DELETE | /api/categories/{id} | **Owner** Organiser | Update / delete |
| POST | /api/enrolments | Participant | Enrol |
| GET | /api/users/{id}/enrolments | Owner / Organiser | List enrolments |
| POST | /api/results | **Owner** Organiser | Record result |
| GET | /api/categories/{id}/results | Public | Leaderboard |
| PUT/DELETE | /api/results/{id} | **Owner** Organiser | Update / delete |

Session cookie is used for authentication after login.
