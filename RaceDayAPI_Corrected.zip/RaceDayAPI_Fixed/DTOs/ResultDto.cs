using System.ComponentModel.DataAnnotations;

public class ResultDto
{
    [Required]
    public int EnrolmentID { get; set; }

    [Required]
    public TimeSpan FinishTime { get; set; }

    public int? OverallPosition { get; set; }
}
