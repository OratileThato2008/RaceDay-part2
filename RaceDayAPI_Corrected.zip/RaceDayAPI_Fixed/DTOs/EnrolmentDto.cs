using System.ComponentModel.DataAnnotations;

public class EnrolmentDto
{
    [Required]
    public int CategoryID { get; set; }
}
