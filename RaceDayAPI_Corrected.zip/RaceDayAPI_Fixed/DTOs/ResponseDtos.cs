/// <summary>
/// Safe response DTOs – never expose PasswordHash or unnecessary navigation graphs.
/// </summary>

public class UserResponseDto
{
    public int UserID { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string UserRole { get; set; } = string.Empty;
}

public class EventResponseDto
{
    public int EventID { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public string Location { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DateTime CreatedAt { get; set; }
    public int OrganiserID { get; set; }
    public string? OrganiserName { get; set; }
}

public class CategoryResponseDto
{
    public int CategoryID { get; set; }
    public int EventID { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public decimal DistanceKm { get; set; }
    public decimal EntryFee { get; set; }
}

public class EnrolmentResponseDto
{
    public int EnrolmentID { get; set; }
    public int ParticipantID { get; set; }
    public string? ParticipantName { get; set; }
    public int CategoryID { get; set; }
    public string? CategoryName { get; set; }
    public int? EventID { get; set; }
    public string? EventName { get; set; }
    public DateTime EnrolmentDate { get; set; }
}

public class ResultResponseDto
{
    public int ResultID { get; set; }
    public int EnrolmentID { get; set; }
    public TimeSpan FinishTime { get; set; }
    public int? OverallPosition { get; set; }
    public string? ParticipantName { get; set; }
    public int? ParticipantID { get; set; }
}
