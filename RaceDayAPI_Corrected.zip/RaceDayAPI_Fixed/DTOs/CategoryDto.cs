using System.ComponentModel.DataAnnotations;

public class CategoryDto
{
    [Required, MaxLength(100)]
    public string CategoryName { get; set; } = string.Empty;

    [Required, Range(0.01, 1000)]
    public decimal DistanceKm { get; set; }

    [Range(0, 100000)]
    public decimal EntryFee { get; set; } = 0.00m;
}
